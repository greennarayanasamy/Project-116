# importing modules from flask library
from flask import Flask , render_template

# creating instance of class Flask, by providing __name__ keyword as argument
app = Flask(__name__)

# write the routes using decorator functions
# default route or 'URL'
@app.route("/")
def home():

    name = "Green" # write your name
    age = "14" # write your age

    return render_template('index.html' , name = name , age = age)

# define the route to father webpage
@app.route("/")
def father():
    #Create a variable
    father_name = 'John'
    father_age="56"
    return render_template('index.html', father_name = father_name, age=father_age)

# define the route to mother webpage
@app.route("/")
def mother():
    #Create a variable
    mother_name = 'Mellissa'
    mother_age="56"
    return render_template('index.html', mother_name = mother_name, age=mother_age)

# define the route to friends webpage
@app.route("/")
def friend():
    #Create a variable
    friend_name = 'Gracie'
    friend_age="15"
    return render_template('index.html', friend_name = friend_name, age=friend_name)

# add other routes, if you want




# run the file
if __name__  ==  '__main__':
    app.run(debug=True)
